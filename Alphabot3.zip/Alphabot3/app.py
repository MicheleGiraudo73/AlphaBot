from flask import Flask, render_template, redirect, url_for, request
import threading as thr
import time
app = Flask(__name__)
import sqlite3
import random
import string

token = ''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(16))

def validate(username, password):
    completion = False
    conn = None
    try:
        conn = sqlite3.connect('C:\Michele\Scuola21-22\TPSIT\Flask\Alphabot2\databaseAlphabot.db')
    except:
        print("__")
    
    cur = conn.cursor()
    try:
        cur.execute("SELECT * FROM USERS")
    except:
        print("CIAO")
    rows = cur.fetchall()
    
    for row in rows:
        dbUser = row[0]
        dbPass = row[1]
        
        if dbUser==username:
            completion=check_password(dbPass, password)
    return completion

def check_password(hashed_password, user_password):
    return hashed_password == user_password

@app.route('/', methods=['GET', 'POST'])

def login():
    error = None
    if request.method == 'POST': #se uguale a GET fa il return della pagina login
        
        username = request.form['username']
        password = request.form['password']

        completion = validate(username, password)
        if completion ==False:
            error = 'Invalid Credentials. Please try again.'
        else:
            
            return redirect(url_for('index'))
    return render_template('login.html', error=error)




class AlphaBot(object):
    def __init__(self):
        pass
    def forward(self):
        print("forward")
    def backward(self):
        print("backword")       
    def right(self):
        print("right")
    def left(self):
        print("left")
    def stop(self):
        print("stop")
    def gestisci(self,comando):
        print(comando)
        print("dio")

@app.route(f'/{token}', methods=['GET', 'POST'])
def index():
    bot = AlphaBot()
    if request.method == 'POST':
        
        if(request.form['inputQuery'] != ''):
            #print(request.form['inputQuery'])
            bot.gestisci(request.form['inputQuery'])
        elif request.form.get('avanti') == 'â†‘':
            bot.forward()
        elif  request.form.get('indietro') == 'â†“':
            bot.backward()
        elif  request.form.get('destra') == 'â†’':
            bot.right()
        elif  request.form.get('sinistra') == 'â†':
            bot.left()
        elif  request.form.get('stop') == 'stop':
            bot.stop()
        else:
            print("ciao")
    elif request.method == 'GET':
        return render_template('index.html')
    
    return render_template("index.html")

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0')